import sys
import os
import numpy as np
import torch
import torch.optim as optim
import torch.nn.functional as F
from tqdm import tqdm
from datetime import datetime

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from LLM4RL.environment.cloud_edge_env import CloudEdgeDeviceEnv
from LLM4RL.algos.maac.maac_agent import MAACAgent
from LLM4RL.algos.maac.attention_critic import AttentionCritic
from LLM4RL.algos.maac.buffer import SharedReplayBuffer
from LLM4RL.utils.config import load_config
from LLM4RL.utils.path_manager import get_path_manager

def train_maac():
    # 1. Setup
    config = load_config("config.yaml")
    path_manager = get_path_manager()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Environment
    env = CloudEdgeDeviceEnv(config['environment'])
    num_agents = env.num_devices
    state_dim = env.get_agent_state_dim()
    action_dim = env.action_space.shape[0]
    max_action = env.action_space.high[1]
    
    print(f"MAAC Training Started: {num_agents} Agents, State Dim {state_dim}, Action Dim {action_dim}")
    
    # 2. Initialize Agents & Critic
    agents = [MAACAgent(i, state_dim, action_dim, max_action, device=device) for i in range(num_agents)]
    
    critic = AttentionCritic(state_dim, action_dim, num_agents).to(device)
    critic_target = AttentionCritic(state_dim, action_dim, num_agents).to(device)
    critic_target.load_state_dict(critic.state_dict())
    critic_optimizer = optim.Adam(critic.parameters(), lr=1e-3)
    
    # Buffer
    buffer_capacity = config.get('maddpg', {}).get('buffer_size', 100000)
    batch_size = config.get('maddpg', {}).get('batch_size', 256)
    replay_buffer = SharedReplayBuffer(buffer_capacity, num_agents, state_dim, action_dim)
    
    # Hyperparameters
    gamma = config.get('maddpg', {}).get('gamma', 0.95)
    tau = config.get('maddpg', {}).get('tau', 0.01)
    num_episodes = config.get('maddpg', {}).get('num_episodes', 100)
    max_steps = env.max_steps
    
    # Training Loop
    metrics = {'rewards': [], 'energy': [], 'delay': []}
    
    for episode in tqdm(range(num_episodes)):
        state = env.reset()
        if isinstance(state, tuple):
            state = state[0]
        # Reset RNN hidden states
        for agent in agents:
            agent.reset_hidden()
            
        episode_reward = 0
        episode_energy = 0
        episode_delay = 0
        
        for step in range(max_steps):
            # Collect actions
            actions = []
            agent_states = []
            
            # Explore/Exploit
            noise = 0.1 if episode < num_episodes * 0.1 else 0.01
            
            for i, agent in enumerate(agents):
                s_i = env.extract_agent_state(state, i)
                agent_states.append(s_i)
                a_i = agent.select_action(s_i, noise_scale=noise)
                actions.append(a_i)
            
            # Step Env
            # Environment expects a flat list or array of actions for all agents
            # Need to combine actions into the format env expects
            # env.step takes an array of shape (num_agents, action_dim) or similar
            # Looking at cloud_edge_env.py step method: it iterates over num_devices
            
            # actions is list of numpy arrays.
            # Fix: env.step returns 5 values (obs, reward, terminated, truncated, info)
            step_result = env.step(actions)
            if len(step_result) == 5:
                next_state, rewards, terminated, truncated, info = step_result
                done = terminated or truncated
            else:
                next_state, rewards, done, info = step_result
            
            if isinstance(next_state, tuple):
                next_state = next_state[0]
            
            # Process next states
            next_agent_states = [env.extract_agent_state(next_state, i) for i in range(num_agents)]
            
            # Store in buffer
            # Convert done to list of bools/floats
            dones = [float(done)] * num_agents
            
            replay_buffer.add(agent_states, actions, rewards, next_agent_states, dones)
            
            state = next_state
            episode_reward += sum(rewards)
            
            # Metrics (simplified extraction from info or sum)
            # Assuming info contains lists
            if 'energy' in info:
                episode_energy += sum(info['energy'])
            if 'delay' in info:
                episode_delay += sum(info['delay'])
            
            # TRAIN
            if len(replay_buffer) > batch_size and step % 5 == 0:
                # Sample
                b_states, b_actions, b_rewards, b_next_states, b_dones = replay_buffer.sample(batch_size)
                
                b_states = b_states.to(device)
                b_actions = b_actions.to(device)
                b_rewards = b_rewards.to(device)
                b_next_states = b_next_states.to(device)
                b_dones = b_dones.to(device)
                
                # --- Update Critic ---
                with torch.no_grad():
                    # Get target actions for next state
                    target_actions = []
                    for i, agent in enumerate(agents):
                        # b_next_states[:, i] is (batch, state_dim)
                        a_next, _ = agent.actor_target(b_next_states[:, i])
                        target_actions.append(a_next)
                    
                    target_actions = torch.stack(target_actions, dim=1) # (batch, N, act_dim)
                    
                    # Target Q
                    target_q = critic_target(b_next_states, target_actions)
                    
                    # Bellman
                    # b_rewards is (batch, N)
                    # b_dones is (batch, N)
                    y = b_rewards + (1 - b_dones) * gamma * target_q
                
                # Current Q
                current_q = critic(b_states, b_actions)
                
                critic_loss = F.mse_loss(current_q, y)
                
                critic_optimizer.zero_grad()
                critic_loss.backward()
                critic_optimizer.step()
                
                # --- Update Actors ---
                for i, agent in enumerate(agents):
                    # We need to take gradients w.r.t agent i's action
                    # So we re-compute the action with gradient flow
                    
                    curr_actions_list = []
                    for j, other_agent in enumerate(agents):
                        if i == j:
                            # Pass None as hidden state for training (stateless update or use stored trajectories if full DRQN)
                            # For simplicity in standard MAAC loop, we treat each step as independent or use zero hidden
                            # To properly train RNN, we need sequences. 
                            # Ideally: Sample sequences from buffer.
                            # For now (Step-based update): Use zero hidden state (behaves like MLP with extra weights)
                            # OR: Just run one step. GRU will handle it.
                            curr_action, _ = agent.actor(b_states[:, i])
                        else:
                            # Detached actions for others
                            with torch.no_grad():
                                curr_action, _ = other_agent.actor(b_states[:, j])
                        curr_actions_list.append(curr_action)
                        
                    curr_actions_tensor = torch.stack(curr_actions_list, dim=1)
                    
                    # Critic value
                    # We want to Maximize Q, so minimize -Q
                    actor_loss = -critic(b_states, curr_actions_tensor)[:, i].mean()
                    actor_loss += (curr_actions_list[i]**2).mean() * 1e-3
                    
                    agent.actor_optimizer.zero_grad()
                    actor_loss.backward()
                    agent.actor_optimizer.step()
                    
                    # Soft update
                    agent.update_target(tau)
                    
                # Update Critic Target
                for param, target_param in zip(critic.parameters(), critic_target.parameters()):
                    target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)

        print(f"Episode {episode}: Reward {episode_reward:.2f}, Energy {episode_energy:.2f}")
        
    # Save Model
    # Use path_manager to get model path
    save_dir = path_manager.get_model_path("maac")
    os.makedirs(save_dir, exist_ok=True)
    
    # Save Critic
    torch.save(critic.state_dict(), os.path.join(save_dir, "critic.pth"))
    # Save Agents
    for i, agent in enumerate(agents):
        torch.save(agent.actor.state_dict(), os.path.join(save_dir, f"actor_{i}.pth"))
        
    print(f"Training Complete. Models saved to {save_dir}")

if __name__ == "__main__":
    train_maac()
