import torch
import torch.nn as nn
import torch.nn.functional as F

class AttentionCritic(nn.Module):
    """
    Attention-based Centralized Critic for Multi-Agent Reinforcement Learning.
    Uses attention mechanism to weigh the importance of other agents' information.
    """
    def __init__(self, state_dim, action_dim, num_agents, hidden_dim=128, attend_heads=4):
        super(AttentionCritic, self).__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.num_agents = num_agents
        self.attend_heads = attend_heads
        
        # Encoder for (state, action) pair of each agent
        self.sa_encoder = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Attention Mechanism
        # Query: derived from the agent's own encoding
        # Key/Value: derived from other agents' encodings
        self.key_layer = nn.Linear(hidden_dim, hidden_dim)
        self.query_layer = nn.Linear(hidden_dim, hidden_dim)
        self.value_layer = nn.Linear(hidden_dim, hidden_dim)
        
        # Post-Attention processing
        self.post_attention = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), # Own encoding + Context
            nn.ReLU(),
            nn.Linear(hidden_dim, 1) # Q-value output
        )

    def forward(self, states, actions):
        """
        Args:
            states: (batch_size, num_agents, state_dim)
            actions: (batch_size, num_agents, action_dim)
        Returns:
            q_values: (batch_size, num_agents) - Q-value for each agent
        """
        batch_size = states.shape[0]
        
        # 1. Encode (state, action) for all agents
        # input: (batch, num_agents, state_dim + action_dim)
        sa_inputs = torch.cat([states, actions], dim=2)
        # encodings: (batch, num_agents, hidden_dim)
        encodings = self.sa_encoder(sa_inputs)
        
        # 2. Calculate Attention
        # Reshape for multi-head attention if needed, simpler version here (1 head concept manually or using logic)
        # Let's do a simple manual attention for clarity and stability
        
        keys = self.key_layer(encodings)   # (batch, N, hidden)
        queries = self.query_layer(encodings) # (batch, N, hidden)
        values = self.value_layer(encodings) # (batch, N, hidden)
        
        # Score: Query * Key^T
        # We want to compute attention for agent i using others j
        # scores[b, i, j] = Q[b, i] dot K[b, j]
        scores = torch.matmul(queries, keys.transpose(-2, -1)) # (batch, N, N)
        
        # Scale
        scores = scores / (encodings.shape[-1] ** 0.5)
        
        # Mask self-attention? usually in MAAC we include self or handle it. 
        # Standard MAAC uses others to form context. Let's keep all for now (global view).
        
        weights = F.softmax(scores, dim=-1) # (batch, N, N)
        
        # Context: Weights * Values
        context = torch.matmul(weights, values) # (batch, N, hidden)
        
        # 3. Combine Own Encoding with Context
        combined = torch.cat([encodings, context], dim=2) # (batch, N, 2*hidden)
        
        # 4. Compute Q-values
        q_values = self.post_attention(combined).squeeze(-1) # (batch, N)
        
        return q_values
