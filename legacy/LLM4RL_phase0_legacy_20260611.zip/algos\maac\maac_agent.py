import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class RecurrentActor(nn.Module):
    """
    Enhanced Actor with LSTM/GRU to capture temporal dependencies.
    Useful for task offloading where past channel states or workload history matters.
    """
    def __init__(self, state_dim, action_dim, max_action, hidden_dim=128):
        super(RecurrentActor, self).__init__()
        
        # Feature extraction
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.relu = nn.ReLU()
        
        # Recurrent Layer (GRU is often faster/simpler than LSTM and sufficient)
        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        
        # Output layers
        self.fc2 = nn.Linear(hidden_dim, 64)
        self.out = nn.Linear(64, action_dim)
        
        self.max_action = max_action
        self.hidden_dim = hidden_dim

    def forward(self, state, hidden=None):
        # state: [batch, seq_len, state_dim] or [batch, state_dim]
        # If input is [batch, state_dim], unsqueeze to [batch, 1, state_dim]
        if len(state.shape) == 2:
            state = state.unsqueeze(1)
            
        x = self.relu(self.fc1(state))
        
        # GRU forward
        # output: [batch, seq_len, hidden_dim]
        # hn: [1, batch, hidden_dim]
        x, hn = self.gru(x, hidden)
        
        # Take the last time step output for action generation
        x = x[:, -1, :] 
        
        x = self.relu(self.fc2(x))
        action_raw = self.out(x)
        
        # Non-inplace modifications for safety
        action = torch.zeros_like(action_raw)
        
        # 1. Task Segmentation Ratios [α1, α2, α3] -> Sigmoid + Normalization
        # Sigmoid to get (0, 1)
        raw_ratios = torch.sigmoid(action_raw[:, :3])
        # Softmax to ensure sum = 1 (Better for ratios than simple Sigmoid)
        # However, if env handles normalization, Sigmoid is fine. 
        # Let's use Softmax for stricter adherence to "ratios".
        action[:, :3] = torch.softmax(action_raw[:, :3], dim=1)
        
        # 2. Edge Server Selection -> Sigmoid (or Softmax if discrete mapped to continuous)
        if action.shape[1] > 3:
            # If it's a single continuous value for ID
            action[:, 3] = torch.sigmoid(action_raw[:, 3])
            
        return action, hn

class MAACAgent:
    """
    Multi-Agent Actor-Attention-Critic Agent with Recurrent Actor.
    """
    def __init__(self, agent_idx, state_dim, action_dim, max_action, lr=1e-4, device='cpu', hidden_dim=128):
        self.agent_idx = agent_idx
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = device
        self.hidden_dim = hidden_dim
        
        self.actor = RecurrentActor(state_dim, action_dim, max_action, hidden_dim).to(device)
        self.actor_target = RecurrentActor(state_dim, action_dim, max_action, hidden_dim).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        
        # Store hidden state for inference (single episode flow)
        self.hidden_state = None

    def reset_hidden(self):
        self.hidden_state = None

    def select_action(self, state, noise_scale=0.0):
        # state: numpy array [state_dim]
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device) # [1, state_dim]
            
            # Forward with stored hidden state
            action_tensor, self.hidden_state = self.actor(state_tensor, self.hidden_state)
            action = action_tensor.cpu().data.numpy()[0]
        
        if noise_scale > 0:
            noise = np.random.normal(0, noise_scale, size=self.action_dim)
            # Clip segmentation to [0, 1]
            action[:3] = np.clip(action[:3] + noise[:3], 0, 1)
            # Re-normalize ratios if needed, but env usually handles it.
            # Clip edge selection
            if len(action) > 3:
                action[3] = np.clip(action[3] + noise[3], 0, 1)
            
        return action

    def update_target(self, tau):
        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)
