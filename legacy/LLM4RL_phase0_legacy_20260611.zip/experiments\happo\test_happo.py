import numpy as np
import torch
import os
from LLM4RL.environment.cloud_edge_env import CloudEdgeDeviceEnv
from LLM4RL.algos.happo.happo_agent import HAPPOAgent
from LLM4RL.utils.config import load_config
from LLM4RL.utils.path_manager import get_path_manager
from LLM4RL.utils.csv_saver import save_test_results_csv


def test_happo(model_path=None, config=None):
    if config is None:
        config = load_config()

    path_manager = get_path_manager()
    if model_path is None:
        model_path = path_manager.get_model_path("happo")

    print(f"🔧 [HAPPO测试] 模型路径: {model_path}")
    env = CloudEdgeDeviceEnv(config['environment'])

    state_dim = env.get_agent_state_dim()
    action_dim = env.action_space.shape[0]
    num_agents = env.num_devices
    num_edges = env.num_edges

    agents = []
    loaded = 0
    for i in range(num_agents):
        agent = HAPPOAgent(
            state_dim=state_dim,
            action_dim=action_dim,
            global_state_dim=env.observation_space.shape[0],
            agent_idx=i,
            config=config.get('happo', {})
        )

        actor_path = os.path.join(model_path, f"actor_agent_{i}_final.pth")
        critic_path = os.path.join(model_path, f"critic_agent_{i}_final.pth")
        if os.path.exists(actor_path):
            try:
                agent.actor.load_state_dict(torch.load(actor_path))
                agent.actor.eval()
                loaded += 1
                print(f"  ✅ 加载Actor: {actor_path}")
            except Exception as e:
                print(f"  ❌ 加载Actor失败: {e}")
        if os.path.exists(critic_path):
            try:
                agent.critic.load_state_dict(torch.load(critic_path))
                agent.critic.eval()
            except Exception as e:
                print(f"  ❌ 加载Critic失败: {e}")
        agents.append(agent)

    if loaded == 0:
        print("❌ 未加载到HAPPO模型，跳过测试")
        return [], [], []

    num_episodes = config['testing']['num_episodes']
    max_steps = config['happo']['max_steps']
    all_energy, all_util, all_delay = [], [], []

    for ep in range(num_episodes):
        state, _ = env.reset()
        ep_energy = ep_util = ep_delay = 0.0
        steps = 0
        for t in range(max_steps):
            actions_env = []
            for i, agent in enumerate(agents):
                agent_state = env.extract_agent_state(state, i)
                action_raw, _ = agent.select_action(agent_state, state, deterministic=True)
                edge_val = action_raw[-1]
                edge_id = int(np.clip(np.floor(edge_val * num_edges), 0, num_edges - 1))
                action_env = np.array([action_raw[0], action_raw[1], action_raw[2], edge_id], dtype=np.float32)
                actions_env.append(action_env)
            next_state, rewards, terminated, truncated, info = env.step(np.array(actions_env, dtype=np.float32))
            done = terminated or truncated
            ep_energy += sum(info['energies'])
            ep_delay += sum(info['delays'])
            ep_util += sum(info['utilizations'])
            steps += 1
            state = next_state
            if done:
                break
        all_energy.append(ep_energy / num_agents)
        all_delay.append(ep_delay / num_agents)
        all_util.append(ep_util / (num_agents * steps) if steps > 0 else 0)

        if (ep + 1) % 10 == 0:
            print(f"[HAPPO] Episode {ep+1}/{num_episodes} 能耗:{all_energy[-1]:.4f} 利用率:{all_util[-1]:.4f} 时延:{all_delay[-1]:.4f}")

    results = {
        'algorithm': 'HAPPO',
        'num_episodes': num_episodes,
        'avg_energy': float(np.mean(all_energy)),
        'avg_utilization': float(np.mean(all_util)),
        'avg_delay': float(np.mean(all_delay)),
        'energy_std': float(np.std(all_energy)),
        'utilization_std': float(np.std(all_util)),
        'delay_std': float(np.std(all_delay)),
        'all_episode_energy': all_energy,
        'all_episode_utilization': all_util,
        'all_episode_delay': all_delay,
    }

    try:
        import json
        result_file = path_manager.get_test_results_file_path("happo_test_results.json")
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)
        save_test_results_csv(results, "HAPPO", path_manager.get_test_results_path())
        print(f"  ✅ HAPPO测试结果保存至: {result_file}")
    except Exception as e:
        print(f"  ❌ 保存HAPPO测试结果失败: {e}")

    return all_energy, all_util, all_delay


if __name__ == "__main__":
    test_happo()