import numpy as np
import random
import torch

class SharedReplayBuffer:
    """
    Multi-Agent Replay Buffer that stores synchronized experiences for all agents.
    """
    def __init__(self, capacity, num_agents, state_dim, action_dim):
        self.capacity = capacity
        self.num_agents = num_agents
        self.ptr = 0
        self.size = 0
        
        # Pre-allocate memory for efficiency
        # obs: [capacity, num_agents, state_dim]
        self.obs = np.zeros((capacity, num_agents, state_dim), dtype=np.float32)
        # actions: [capacity, num_agents, action_dim]
        self.actions = np.zeros((capacity, num_agents, action_dim), dtype=np.float32)
        # rewards: [capacity, num_agents]
        self.rewards = np.zeros((capacity, num_agents), dtype=np.float32)
        # next_obs: [capacity, num_agents, state_dim]
        self.next_obs = np.zeros((capacity, num_agents, state_dim), dtype=np.float32)
        # dones: [capacity, num_agents]
        self.dones = np.zeros((capacity, num_agents), dtype=np.float32)

    def add(self, obs, actions, rewards, next_obs, dones):
        """
        Add a synchronized step to the buffer.
        Inputs should be lists or arrays of length num_agents.
        """
        self.obs[self.ptr] = np.array(obs)
        self.actions[self.ptr] = np.array(actions)
        self.rewards[self.ptr] = np.array(rewards)
        self.next_obs[self.ptr] = np.array(next_obs)
        self.dones[self.ptr] = np.array(dones)
        
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        """
        Sample a batch of synchronized experiences.
        Returns tensors.
        """
        idxs = np.random.randint(0, self.size, size=batch_size)
        
        return (
            torch.FloatTensor(self.obs[idxs]),
            torch.FloatTensor(self.actions[idxs]),
            torch.FloatTensor(self.rewards[idxs]),
            torch.FloatTensor(self.next_obs[idxs]),
            torch.FloatTensor(self.dones[idxs])
        )

    def __len__(self):
        return self.size
